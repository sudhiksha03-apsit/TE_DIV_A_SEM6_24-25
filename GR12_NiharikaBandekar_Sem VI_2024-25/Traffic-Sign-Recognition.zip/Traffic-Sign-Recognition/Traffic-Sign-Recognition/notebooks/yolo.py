import cv2
import torch
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.applications.vgg16 import preprocess_input
import streamlit as st
from PIL import Image

def load_yolo_model():
    return torch.hub.load('ultralytics/yolov5', 'yolov5s')  # Load YOLOv5 model

def load_vgg_model():
    return load_model("vgg16_trained_model.keras")

def detect_traffic_signs(yolo_model, image):
    results = yolo_model(image)
    return results.pandas().xyxy[0]  # Bounding boxes in pandas DataFrame

def crop_detected_objects(image, detections):
    cropped_images = []
    for _, row in detections.iterrows():
        x1, y1, x2, y2 = int(row['xmin']), int(row['ymin']), int(row['xmax']), int(row['ymax'])
        cropped = image[y1:y2, x1:x2]
        cropped_images.append(cropped)
    return cropped_images

def classify_signs(vgg_model, cropped_images):
    class_labels = ['Speed Limit', 'Keep Left', 'Keep Right', 'No passing', 'Priority Road', 'Road Work', 'Stop', 'Yield', 'No Parking']
    predictions = []
    for img in cropped_images:
        img = cv2.resize(img, (112, 112))
        img_array = np.expand_dims(preprocess_input(img), axis=0)
        pred = vgg_model.predict(img_array)
        predicted_class = np.argmax(pred)
        predictions.append(class_labels[predicted_class] if predicted_class < len(class_labels) else "Unknown")
    return predictions

def main():
    st.title("Traffic Sign Detection & Classification")
    uploaded_file = st.file_uploader("Upload an image", type=["jpg", "png", "jpeg"])
    
    if uploaded_file:
        image = Image.open(uploaded_file)
        image_np = np.array(image)
        
        yolo_model = load_yolo_model()
        vgg_model = load_vgg_model()
        
        detections = detect_traffic_signs(yolo_model, image_np)
        cropped_signs = crop_detected_objects(image_np, detections)
        classifications = classify_signs(vgg_model, cropped_signs)
        
        st.image(image, caption="Uploaded Image", use_column_width=True)
        
        for i, (crop, label) in enumerate(zip(cropped_signs, classifications)):
            st.image(crop, caption=f"Detected Sign {i+1}: {label}", use_column_width=False)
            st.write(f"**Classified as:** {label}")

if __name__ == "__main__":
    main()
