
import streamlit as st
import cv2
import numpy as np
import tensorflow as tf
from ultralytics import YOLO  # YOLOv8 for object detection
from PIL import Image

# Load YOLO model (detection)
detector = YOLO(r"C:\Users\aabha\OneDrive\Desktop\Traffic-Sign-Recognition\notebooks\yolov8_traffic_signs.pt")  # Ensure correct model path

# Load VGG16 model (classification)
classifier = tf.keras.models.load_model(r"C:\Users\aabha\OneDrive\Desktop\Traffic-Sign-Recognition\notebooks\vgg16_trained_model.keras")  # Ensure correct model path

# Define class labels
class_info = {
    'Speed Limit': "This sign indicates the maximum speed allowed on this road.",
    'Keep Left': "Vehicles must stay to the left side of the road or divider.",
    'Keep Right': "Vehicles must stay to the right side of the road or divider.",
    'No Passing': "Overtaking other vehicles is not allowed beyond this point.",
    'Priority Road': "This road has the right of way over intersecting roads.",
    'Road Work': "Indicates construction work ahead. Drive with caution.",
    'Stop': "Come to a complete stop before proceeding.",
    'Yield': "Give way to other vehicles before moving ahead.",
    'No Parking': "Parking is prohibited in this area."
}

# Function to preprocess images for classification
def preprocess_image(img):
    img = cv2.resize(img, (112, 112))  # Match model input size
    img = img / 255.0  # Normalize
    img = np.expand_dims(img, axis=0)  # Add batch dimension
    return img

# Function for detection and classification
def detect_and_classify(image):
    results = detector(image)
    detections = results[0].boxes.xyxy.cpu().numpy()  # Bounding boxes

    img_with_boxes = image.copy()
    classifications = []

    for box in detections:
        x1, y1, x2, y2 = map(int, box[:4])
        cropped_sign = image[y1:y2, x1:x2]

        if cropped_sign.size == 0:
            continue  # Skip invalid detections

        preprocessed_sign = preprocess_image(cropped_sign)
        prediction = classifier.predict(preprocessed_sign)
        predicted_class = np.argmax(prediction)
        confidence = np.max(prediction)

        detected_label = list(class_info.keys())[predicted_class]


        classifications.append((x1, y1, x2, y2, detected_label, confidence))
        cv2.rectangle(img_with_boxes, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(img_with_boxes, f"{detected_label} ({confidence:.2f})", 
                    (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    return img_with_boxes, classifications



# Streamlit UI
st.title("🚦 Traffic Sign Detection & Classification")

uploaded_file = st.file_uploader("Upload an Image", type=["jpg", "png", "jpeg"])

if uploaded_file:
    image = Image.open(uploaded_file)
    image = np.array(image)
    st.image(image, caption="Uploaded Image", use_column_width=True)

    img_with_boxes, classifications = detect_and_classify(image)
    st.image(img_with_boxes, caption="Detection & Classification Results", use_column_width=True)

    st.write("### Detected Signs:")
    for x1, y1, x2, y2, label, conf in classifications:
        st.write(f"**🔹 {label}** detected at ({x1}, {y1}) to ({x2}, {y2}) with **{conf:.2f}** confidence")
        st.write(f"ℹ️ **Info:** {class_info[label]}")  # ✅ Show meaning of the sign
        st.write("---")